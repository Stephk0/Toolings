"""bpy-free logic."""
