# Blender GeoNode Layout MCP

Read a **Geometry Nodes** graph as an annotated screenshot **plus** structured
data, then rearrange it **deterministically** — in a 2-round-trip loop.

The screenshot exists for exactly one reason: layout/readability is a *visual*
judgment the serialized tree can't carry. Topology and writes are handled as
data, never as pixels.

## Mental model — judge once, write once

1. **`capture_graph`** → one response carrying an annotated image *and* an
   identity+coordinate table (each node stamped with an integer index).
2. The model reasons over the whole graph and emits the **entire** new layout.
3. **`apply_layout`** writes every `node.location` in **one batched pass**.
4. *(optional)* **`capture_graph`** again to verify it reads cleanly.

Core loop = **2 round trips** (3 with verify). Never re-capture between writes —
writes are deterministic, so the model already knows where it placed everything.

`autolayout_pass` is a shortcut: it computes a clean left-to-right layered layout
deterministically and returns the `moves` for you to review and hand to
`apply_layout` (it does **not** auto-apply).

## Architecture

Mirrors the `ahujasid/blender-mcp` split:

| Piece | File | Role |
|-------|------|------|
| Blender addon | `geonode_layout_addon/` | TCP socket server inside Blender + main-thread queue + 3 handlers |
| MCP server | `server.py` | FastMCP process; each tool forwards a JSON command over the socket |
| Layout engine | `geonode_layout_addon/layout.py` | deterministic layered layout (pure stdlib, unit-testable) |
| Version shims | `geonode_layout_addon/compat.py` | all version-specific names in one place |

> Deliverable mapping: the spec's `addon.py` is `geonode_layout_addon/__init__.py`
> (a Blender **package** so `layout.py`/`compat.py` import cleanly); `layout.py`
> lives inside that package since only the addon consumes it.

**Concurrency rule (the hard part).** `bpy` is not thread-safe. The socket thread
never touches `bpy`: it pushes a callable onto a queue, blocks on a
`threading.Event`, and the main thread drains the queue via
`bpy.app.timers.register`, runs the handler, and signals the result back. Every
handler runs on the main thread. See the docstring at the top of
`geonode_layout_addon/__init__.py`.

## Install

### 1. Blender addon

- Zip the **`geonode_layout_addon/`** folder (so the zip root contains
  `geonode_layout_addon/__init__.py`), then in Blender:
  `Edit ▸ Preferences ▸ Add-ons ▸ Install…` and pick the zip. Enable
  **"GeoNode Layout MCP Bridge"**.
- In a **Geometry Nodes editor**, open the **N-panel ▸ "GN Layout MCP"** tab and
  click **Start** (default port `9877`).

### 2. MCP server

```bash
cd blender-geonode-layout-mcp
uv pip install -e .        # or: pip install mcp[cli] pillow
```

Register it with your MCP client (Claude Code / Desktop). Example
`claude_desktop_config.json` / `.mcp.json` entry:

```jsonc
{
  "mcpServers": {
    "geonode-layout": {
      "command": "python",
      "args": ["D:/.../blender-geonode-layout-mcp/server.py"],
      "env": { "GNLAYOUT_PORT": "9877" }
    }
  }
}
```

Env vars: `GNLAYOUT_HOST` (default `localhost`), `GNLAYOUT_PORT` (default `9877`),
`GNLAYOUT_TIMEOUT` (socket timeout seconds, default `60`).

## Tools

### `capture_graph(tree="active", annotate=true, scale=1.0, max_px=1600)`
Returns `[image, table]`. The image stamps each node's integer index; the table
is JSON with `nodes` (`index`, `name`, `type`, `label`, `loc`, `abs_loc`, `dim`,
`is_frame`, `parent`) and `links` (`from_node`/`to_node` by **index**, plus
socket identifiers). Requires an **open Geometry Nodes editor** showing the tree
— it fails loud (`no NODE_EDITOR area open…`) rather than guessing.

`abs_loc` is the absolute node-space top-left (frame offsets folded in); `dim` is
node-space width/height. **Use `abs_loc`/`dim` for layout math** and feed `abs`
coordinates back to `apply_layout`.

### `apply_layout(moves, tree="active")`
`moves`: `[{ "index": int, "x": float, "y": float }, …]` in **absolute** node
space. One batched write. Frames among the moves are applied before their
children so coordinates resolve correctly.

### `autolayout_pass(tree="active", x_gap=80.0, y_gap=40.0)`
Returns `moves` (not applied) from the deterministic layered engine: longest-path
layering → barycenter ordering → non-overlapping stacking, left-to-right.

## Identity & coordinates — why indices

Vision can place "a Math node" spatially but can't disambiguate three of them.
The stamped integer maps a visual position to one exact `bpy` node. Indices are
`tree.nodes` order, **stable within a session as long as no nodes are
added/removed** — they're echoed in both `nodes` and `links`, and they're the
key `apply_layout` writes against.

`node.dimensions` is only valid **after a UI redraw**, so capture serializes in
the same pass as the screenshot (after the area draws). The index stamps are
drawn *inside Blender* through `region.view2d.view_to_region` — exact by
construction, never PIL-reconstructed, so they stay locked to nodes at any
pan/zoom. Pillow on the server side only **downscales**.

## Version notes

Targets **Blender 4.2 LTS** and **5.x**. Tested against **4.2.x LTS** and
**5.0.x**. Anything version-specific (`blf.size` signature, builtin shader name,
the `screenshot_area` operator, px↔node-space `ui_scale`) lives in
`geonode_layout_addon/compat.py` — look there first when porting.

## Frames

Frame nodes are never positioned by the layout engine (they shrink-wrap their
children). Children inside a frame store frame-relative coordinates; the addon
folds the parent chain in/out so you always work in absolute node space.

## ⚠️ Security note

This bridge executes **writes against the live `.blend`** (it moves nodes in the
open file). Anything connected to the MCP server can rearrange your node graph.
Run it only against work you can recover (saved / versioned), and don't expose
the socket port beyond `localhost`.

## Out of scope

No topology/socket/value editing (layout + read only), no pixel-coordinate write
path, no multi-window capture (assumes one visible node editor).
