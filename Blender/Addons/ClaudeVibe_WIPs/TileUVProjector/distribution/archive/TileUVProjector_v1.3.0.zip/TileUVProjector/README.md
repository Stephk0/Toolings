# Tile UV Projector v1.3.0

Tile-based UV projection and placement for texture atlas workflows in Blender.

## Overview

Select mesh faces, click a tile in the grid, and the addon automatically projects, unwraps, relaxes, and fits the UVs into that tile with padding. Ideal for texture atlas creation and tile-based texturing workflows.

## Features

- **Uniform Grid Mode** - Configurable X/Y grid (default 4x4) with clickable tile buttons
- **Proportional Grid Buttons** - W:H proportion field controls button aspect ratio to match your texture
- **Atlas Texture Preview** - Load your texture atlas and see it above the grid for visual reference
- **Live Texture Updates** - Reload the atlas from disk without leaving the panel; the preview thumbnail and the tile picker overlay always show the same, current picture
- **Custom Atlas Mode** - Define arbitrary UV rectangles for non-uniform atlases
- **Clear Seams** - Clears existing seams on selected faces before unwrapping (fixes incorrect splits)
- **Auto Seams** - Automatically marks seams on selection boundary
- **Multiple Unwrap Methods** - Angle Based, Conformal
- **UV Relaxation** - Optional post-unwrap relaxation with configurable iterations
- **View Projection** - Projects UVs from current viewport before unwrapping
- **Padding Control** - Configurable padding inside each tile to prevent bleeding
- **Tile Splitting** - Split custom tiles horizontally or vertically
- **Grid-to-Custom** - Generate custom tiles from uniform grid as starting point

## Installation

### Method 1: Single File (Recommended)
1. Open Blender > Edit > Preferences > Add-ons
2. Click "Install..."
3. Select `tile_uv_projector.py`
4. Enable the addon

### Method 2: Folder Installation
1. Copy the `TileUVProjector` folder to your Blender addons directory
2. Restart Blender and enable the addon

## Usage

1. Open the **N-panel** in the 3D Viewport
2. Find the **"Tile UV"** tab
3. Enter **Edit Mode** and select faces
4. Configure grid size, unwrap method, and padding
5. Click a tile button in the grid to project UVs into that tile

### Uniform Grid Mode
- Set columns (X) and rows (Y) for your atlas layout
- Each button in the grid shows its (col, row) coordinate
- Grid is drawn with row 0 at the bottom (matching UV space)

### Custom Atlas Mode
- Toggle "Advanced Grid" to switch modes
- Add tiles manually or generate from uniform grid
- Edit tile UV bounds (Min U/V, Max U/V)
- Split tiles horizontally or vertically for subdivision
- Click "Apply to [tile]" to project into the selected tile

### Updating the Atlas Texture

Both **Grid Settings** and the **Grid** panel show the atlas texture's state
directly under the image field:

- A status line with the resolution (`2048 x 2048`), or a red warning when the
  file is missing or the pixel data is not loaded
- **Reload** — re-reads the image from disk (`Image.reload`) and rebuilds its
  preview thumbnail. Use this after re-exporting the atlas from Photoshop /
  Substance / etc.
- **Refresh Preview** — rebuilds only the thumbnail from the pixel data already
  in memory. Use it for generated or painted images that were never on disk.
- **Find Missing Files** — appears only when the atlas path is broken, and opens
  Blender's standard missing-file search.

The picker overlay never draws Blender's magenta "missing image" placeholder. If
the atlas has no usable pixels it draws a dark panel with the reason written
across it, and the grid stays clickable. Opening the picker on an unloaded image
reloads it automatically first.

## Settings

| Setting | Description | Default |
|---------|-------------|---------|
| Columns/Rows | Grid dimensions | 4x4 |
| Padding | Inner tile padding (UV space) | 0.005 |
| Proportion W:H | Texture aspect ratio for button sizing | 1:1 |
| Atlas Texture | Image to show as preview above grid | None |
| Clear Seams | Clear existing seams on selection before unwrap | On |
| Auto Seams | Mark seams on selection boundary | On |
| Unwrap Method | Angle Based / Conformal | Angle Based |
| Relax | Post-unwrap relaxation | Off |
| Relax Iterations | Number of relaxation passes | 10 |
| Projection | View / Unwrap Only | View |

## Edge Cases

- **No faces selected** - Operation cancelled with warning
- **Zero-area UV bounds** - Operation cancelled with warning
- **Non-uniform scale** - Warning shown, suggests applying transforms
- **Padding too large** - Error if padding exceeds tile size
- **Atlas file missing / unloaded** - Panel shows a red warning with Reload and
  Find Missing Files; the overlay draws the reason instead of a magenta texture
- **Picker torn down by a file load or script reload** - Picker state self-heals,
  so "Pick Tile" never gets stuck showing "Close Picker"

## Changelog

### v1.3.0
- Fixed: reloading or repathing an atlas texture could leave the tile picker
  drawing Blender's magenta *missing image* placeholder. Pixel availability is
  now checked before the GPU texture is built, so the placeholder can never be
  mistaken for the atlas.
- Fixed: the tile picker could get permanently stuck as "active" when Blender
  tore the modal operator down outside `modal()` (file load, area close, script
  reload), which blocked tile picking entirely. Added `cancel()`, a `load_post`
  reset, and a self-healing active check.
- Added: **Reload** and **Refresh Preview** buttons plus a texture status line in
  both Grid Settings and the Grid panel.
- Added: **Find Missing Files** shortcut when the atlas path is broken.
- Added: opening the picker auto-reloads an atlas whose data is not in memory.
- Added: preview-thumbnail fallback so the overlay still shows the picture from
  the preview window when the full-resolution buffer is unavailable.

## Requirements

- Blender 4.5+
- No external dependencies

## Author

Stephan Viranyi (stephko@viranyi.de)
