# Animation Layers Quick Export

One-click non-destructive merge + FBX export for rigs using the
[Animation Layers](https://blendermarket.com/products/animation-layers) addon
by Tal Hershkovich.

## What it does

Animation Layers lets you stack animation clips as layers on a rig. Game
engines like Unity expect a single baked clip, so the standard workflow is
to **merge layers down** (destructive, several clicks) before exporting.
This addon collapses that into one click:

1. Snapshot the current state via Blender's undo system
2. Merge **all** layers using the Animation Layers `Merge Down` operator
3. Export the active armature (and optionally its children) as FBX
4. Undo the merge so the layer stack returns exactly as it was

The animator never sees the bake. They keep working with the layer stack
they had before clicking the button.

## Requirements

- Blender **4.2+**
- Animation Layers addon **2.3.4+** installed and enabled

If Animation Layers isn't detected, the panel and header button gracefully
disable themselves with a clear message.

## Installation

1. Download `AnimLayersQuickExport_v0.1.0.zip`
2. In Blender: `Edit > Preferences > Add-ons > Install from Disk`
3. Pick the zip and enable the addon
4. Make sure **Animation Layers** is also installed and enabled

## Where to find it

- **Header button**: 3D Viewport top-right header, next to the gizmo/overlay toggles.
  Greyed out when the active object isn't an armature with Animation Layers data.
- **Panel**: 3D Viewport sidebar (`N`) → `Animation` tab → inside the
  *Animation Layers* panel as a *Quick Export* sub-panel (collapsed by default).

## Settings

| Setting | What it does |
|---|---|
| **Export Path** | Folder to write the FBX to (relative `//` paths supported). |
| **Filename Source** | `Active Action Name` / `Armature Name` / `Custom`. |
| **Prefix / Suffix** | Strings prepended/appended to the resolved filename. |
| **Scope** | `Active Only` / `Active + Children` / `Selected Armatures + Children`. |
| **Bake Step** | Frame step passed to the Animation Layers merge. |
| **Smart Bake** | Use AL smart-bake (preserves keyframe density). |
| **FBX Animation** | All standard FBX animation flags (all bones, NLA strips, all actions, force start/end keying, sampling rate, simplify). |
| **FBX Armature** | Add leaf bones, primary/secondary bone axes, armature node type. |
| **FBX General** | Unit scale, scale options, bake space transform, axis forward/up, path mode. |

## License

GPL-3.0-or-later
