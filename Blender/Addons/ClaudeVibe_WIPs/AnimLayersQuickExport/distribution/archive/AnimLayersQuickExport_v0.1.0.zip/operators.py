import os

import bpy
from bpy.types import Operator

from . import al_bridge


def _resolve_filename_base(obj, props):
    if props.filename_source == "ACTION":
        anim = getattr(obj, "animation_data", None)
        action = anim.action if anim else None
        base = action.name if action is not None else obj.name
    elif props.filename_source == "ARMATURE":
        base = obj.name
    else:
        base = props.custom_filename or obj.name
    return f"{props.filename_prefix}{base}{props.filename_suffix}"


def _resolve_armatures(context, props):
    obj = context.active_object
    if props.scope == "SELECTED_ARMATURES":
        return [
            o for o in context.selected_objects
            if o.type == "ARMATURE" and al_bridge.has_animation_layers(o)
        ]
    if obj is None or obj.type != "ARMATURE":
        return []
    return [obj]


def _resolve_export_objects(context, props):
    armatures = _resolve_armatures(context, props)
    if not armatures:
        return []
    if props.scope == "ACTIVE_ONLY":
        return list(armatures)
    objects = set(armatures)
    for arm in armatures:
        for child in arm.children_recursive:
            objects.add(child)
    return list(objects)


def _build_fbx_kwargs(props, filepath):
    return {
        "filepath": filepath,
        "use_selection": True,
        "object_types": {"ARMATURE", "MESH", "EMPTY"},
        "bake_anim": True,
        "bake_anim_use_all_bones": props.bake_anim_use_all_bones,
        "bake_anim_use_nla_strips": props.bake_anim_use_nla_strips,
        "bake_anim_use_all_actions": props.bake_anim_use_all_actions,
        "bake_anim_force_startend_keying": props.bake_anim_force_startend_keying,
        "bake_anim_step": props.bake_anim_step,
        "bake_anim_simplify_factor": props.bake_anim_simplify_factor,
        "add_leaf_bones": props.add_leaf_bones,
        "primary_bone_axis": props.primary_bone_axis,
        "secondary_bone_axis": props.secondary_bone_axis,
        "armature_nodetype": props.armature_nodetype,
        "apply_unit_scale": props.apply_unit_scale,
        "apply_scale_options": props.apply_scale_options,
        "bake_space_transform": props.bake_space_transform,
        "axis_forward": props.axis_forward,
        "axis_up": props.axis_up,
        "path_mode": props.path_mode,
    }


class ALQE_OT_quick_export(Operator):
    bl_idname = "alqe.quick_export"
    bl_label = "Quick Export Animation"
    bl_description = (
        "Merge all Animation Layers on the active armature, export to FBX, "
        "then revert the merge so the layer stack stays intact"
    )
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            al_bridge.is_animation_layers_available()
            and obj is not None
            and obj.type == "ARMATURE"
            and al_bridge.has_animation_layers(obj)
        )

    def execute(self, context):
        props = context.scene.alqe_props
        active = context.active_object

        armatures_to_merge = _resolve_armatures(context, props)
        if not armatures_to_merge:
            self.report({"ERROR"}, "No armature with Animation Layers found in scope")
            return {"CANCELLED"}

        export_objects = _resolve_export_objects(context, props)
        if not export_objects:
            self.report({"ERROR"}, "Nothing to export")
            return {"CANCELLED"}

        filename_base = _resolve_filename_base(active, props)
        export_dir = bpy.path.abspath(props.export_path)
        try:
            os.makedirs(export_dir, exist_ok=True)
        except OSError as exc:
            self.report({"ERROR"}, f"Could not create export folder: {exc}")
            return {"CANCELLED"}
        filepath = os.path.join(export_dir, f"{filename_base}.fbx")

        merged_layer_total = 0
        snapshots = {arm.name: al_bridge.snapshot_state(arm) for arm in armatures_to_merge}

        saved_active = context.view_layer.objects.active
        saved_selection = [o for o in context.selected_objects]

        try:
            for armature in armatures_to_merge:
                merged_layer_total += al_bridge.get_layer_count(armature)
                context.view_layer.objects.active = armature
                al_bridge.merge_all_layers(
                    armature,
                    baketype="AL",
                    smartbake=props.smartbake,
                    step=props.bake_step,
                    actioncopy=True,
                )

            bpy.ops.object.select_all(action="DESELECT")
            for o in export_objects:
                o.select_set(True)
            context.view_layer.objects.active = armatures_to_merge[0]

            bpy.ops.export_scene.fbx(**_build_fbx_kwargs(props, filepath))
        except Exception as exc:
            self.report({"ERROR"}, f"Quick export failed: {exc}")
            return self._restore_and_return(snapshots, saved_active, saved_selection, "CANCELLED")

        return self._restore_and_return(
            snapshots, saved_active, saved_selection, "FINISHED",
            success_message=(
                f"Exported {os.path.basename(filepath)} "
                f"({len(armatures_to_merge)} armature(s), {merged_layer_total} layers merged)"
            ),
        )

    def _restore_and_return(self, snapshots, saved_active, saved_selection, retval, success_message=None):
        import bpy
        for name, snapshot in snapshots.items():
            arm = bpy.data.objects.get(name)
            if arm is not None:
                al_bridge.restore_state(arm, snapshot)

        try:
            bpy.ops.object.select_all(action="DESELECT")
            for o in saved_selection:
                if o.name in bpy.data.objects:
                    o.select_set(True)
            if saved_active is not None and saved_active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = saved_active
        except (ReferenceError, RuntimeError):
            pass

        if success_message:
            self.report({"INFO"}, success_message)

        return {retval}


classes = (ALQE_OT_quick_export,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
