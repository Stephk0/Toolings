# Mass Collection Exporter v12.4

A powerful Blender addon for batch exporting collections with advanced parent-child relationship handling, automatic joining, and flexible export options.

## ✨ What's New in v12.4

### Fixed "Export Selected Objects"
- **FIXED**: Now exports ONLY the selected objects, not entire collections
- If selected objects are in a subcollection with "Export Subcollections as Single" enabled, exports the entire subcollection
- Otherwise exports just the selected objects

### Enhanced Status Bar Feedback
- **NEW**: "Export All Collections" now shows names of exported collections in the status bar
- Displays first 3 collection names, with count if more than 3
- Example: "Exported 5 collections: Buildings, Props, Vegetation, ... (5 total)"

### New Per-Collection Properties
- **NEW**: `Apply Modifiers` - Apply all modifiers before export (works for all export types)
- **NEW**: `Move to Center` - Temporarily move objects to world origin (0,0,0) during export (default: ON)

**Note**: Full integration of these new properties throughout all export paths is in progress. Current implementation has the properties added and basic functionality working.

---

## 📋 Quick Start

### Installation

1. Download the `MassExporter_v12.4.zip` file
2. Open Blender
3. Go to: **Edit → Preferences → Add-ons**
4. Click **Install...** and select the zip file
5. Enable the addon by checking the checkbox

### Basic Usage

1. **Open Panel**: Press `N` in 3D Viewport → Select **Mass Exporter** tab
2. **Add Collections**: Click `+` to add collections
3. **Set Export Path**: Click folder icon
4. **Enable Export**: Check the export checkbox
5. **Export**: Click **"Export All Collections"**

---

## 🎯 Key Features

### Core Functionality
- **Batch Collection Export**: Export multiple collections at once
- **Quick Export from Selection**: Export selected objects with one click
- **Suffix Grouping**: Group objects by base name (e.g., cube + cube_COL → cube.fbx)
- **Smart Empty Handling**: Automatic parent empty processing
- **Multiple Formats**: FBX, OBJ, DAE, glTF 2.0

### Export Modes
- Individual objects
- Merged collections
- Sub-collection based
- Suffix-grouped exports

---

## 🔧 Export Options

### Per-Collection Settings
- **Export Enabled**: Toggle export on/off
- **Merge to Single**: Combine all objects into one file
- **Sub-Collections as Single**: Export each sub-collection as merged object
- **Use Parent Empties**: Use empty objects as origins/centers
- **Center Each Empty**: Center empties at origin during export
- **Join Empty Children**: Combine all mesh children into single object
- **Apply Modifiers**: Apply modifiers before export *(NEW in v12.4)*
- **Move to Center**: Move objects to world origin during export *(NEW in v12.4)*
- **Group by Suffix**: Enable suffix-based grouping

### Transform Options
- Export at origin
- Apply transforms
- Axis orientation (Forward/Up)
- FBX-specific scaling

### Material Options
- Override materials
- Assign if no material
- Add M_ prefix

---

## 📖 Usage Examples

### Export Selected Objects Only (FIXED in v12.4)

**Before v12.4**: Exported entire collection
**After v12.4**: Exports ONLY selected objects

```
1. Select specific objects (Ctrl+Click)
2. Click "Export Selected Objects"
3. Result: Only those objects are exported
```

**With Subcollections**:
```
Collection: Buildings (export_subcollections_as_single: ON)
  ├─ Sub: House_A
  │   └─ Wall_01  ← Selected

Result: Entire House_A subcollection exported (respects parent settings)
```

### Export All with Status Feedback (NEW in v12.4)

```
1. Enable multiple collections for export
2. Click "Export All Collections"
3. Status bar shows: "Exported 3 collections: Props, Buildings, Vegetation"
```

### Using Suffix Grouping

```
Objects:
  - sm_cube_4x4
  - sm_cube_4x4_COL
  - sm_cube_4x4_LOD0

Settings:
  ☑ Group by Suffix

Result: Single file "sm_cube_4x4.fbx" containing all three meshes
```

---

## 🐛 Known Issues & Limitations

### v12.4 Status

**Working**:
- ✅ Export Selected Objects (fixed)
- ✅ Status bar feedback with collection names
- ✅ Properties added (apply_modifiers, move_to_center)
- ✅ Suffix grouping
- ✅ All existing v12.3 features

**In Progress**:
- ⏳ Full integration of `apply_modifiers` throughout all export paths
- ⏳ Full integration of `move_to_center` throughout all export paths

The new properties are functional for basic use cases but may not be applied in all export scenarios. Full implementation requires extensive refactoring of export method signatures.

---

## 📝 Version History

### v12.4.0 (Current) - 2026-01-11
- **FIXED**: Export Selected Objects now exports ONLY selected objects
- **NEW**: Status bar shows exported collection names
- **NEW**: Per-collection `Apply Modifiers` property
- **NEW**: Per-collection `Move to Center` property (default ON)
- Improved selection handling in quick export operators

### v12.3.0 - Suffix Grouping
- Added suffix grouping for collision/LOD exports
- Customizable suffix definitions
- Case-insensitive matching

### v12.2.0 - Export Selected Objects
- Added "Export Selected Object(s)" quick export

### v12.1.0 - Quick Export from Selection
- Export collection or sub-collections of selected object

### v12.0.0 - Fallback Export
- Export meshes even when no empties present
- Improved error handling

---

## 🤝 Support

**Author**: Stephan Viranyi (Stephko)
**Email**: stephko@viranyi.de
**Portfolio**: https://www.artstation.com/stephko

### Troubleshooting

1. **Enable Debug Mode** in panel
2. Check **Console** (Window → Toggle System Console)
3. Test with **Debug Tools** buttons
4. Verify **collection structure** in Outliner

---

## 📄 License

Created with Claude AI. Free to use in Blender projects.

---

**Happy Exporting! 🚀**
