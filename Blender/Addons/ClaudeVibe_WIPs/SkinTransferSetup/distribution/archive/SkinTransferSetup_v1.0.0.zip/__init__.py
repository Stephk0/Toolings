# Single source of truth for the addon version. bl_info + blender_manifest.toml
# both derive from this; bump here AND in blender_manifest.toml only.
VERSION = (1, 0, 0)

bl_info = {
    "name": "Skin Transfer Setup",
    "author": "Stephan Viranyi",
    "version": VERSION,
    "blender": (4, 2, 0),
    "location": "3D View > N-Panel > Skin Transfer",
    "description": "Per-part skin setup helper: tag each mesh in a collection as As-is, Data Transfer from a weighted base model, or Bind-to-bone via Vertex Weight Edit. Stores rig + base model centrally so swapping the base retargets every transfer in one click.",
    "category": "Rigging",
}

import bpy
from bpy.props import (
    EnumProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


# Modifier names this addon owns. We look these up by name to update / remove
# them safely without touching user-added modifiers on the same object.
MOD_DATA_TRANSFER = "SkinTransfer_DataXfer"
MOD_VERTEX_WEIGHT = "SkinTransfer_VWEdit"


# ---------------------------------------------------------------------------
# Poll helpers for PointerProperty pickers
# ---------------------------------------------------------------------------

def _poll_armature(self, obj):
    return obj is not None and obj.type == 'ARMATURE'


def _poll_mesh(self, obj):
    return obj is not None and obj.type == 'MESH'


# ---------------------------------------------------------------------------
# Modifier management
# ---------------------------------------------------------------------------

def _remove_addon_modifier(obj, name):
    mod = obj.modifiers.get(name)
    if mod is not None:
        obj.modifiers.remove(mod)


def _ensure_vertex_group(obj, name, weight=1.0):
    """Create vertex group `name` if missing and weight every vertex to it."""
    vg = obj.vertex_groups.get(name)
    if vg is None:
        vg = obj.vertex_groups.new(name=name)
    if obj.data and obj.data.vertices:
        vg.add([v.index for v in obj.data.vertices], weight, 'REPLACE')
    return vg


def _apply_transfer(obj, base_model):
    """Configure obj with a Data Transfer modifier sourcing all vertex
    groups from base_model. Removes any bind-to-bone modifier first."""
    _remove_addon_modifier(obj, MOD_VERTEX_WEIGHT)

    mod = obj.modifiers.get(MOD_DATA_TRANSFER)
    if mod is None:
        mod = obj.modifiers.new(name=MOD_DATA_TRANSFER, type='DATA_TRANSFER')

    mod.object = base_model
    mod.use_vert_data = True
    mod.data_types_verts = {'VGROUP_WEIGHTS'}
    mod.vert_mapping = 'POLYINTERP_NEAREST'
    mod.layers_vgroup_select_src = 'ALL'
    mod.layers_vgroup_select_dst = 'NAME'
    mod.mix_mode = 'REPLACE'
    mod.mix_factor = 1.0


def _apply_bind_to_bone(obj, bone_name):
    """Configure obj with a Vertex Weight Edit modifier pinning every vert
    to `bone_name` at weight 1.0. Removes the Data Transfer modifier first."""
    _remove_addon_modifier(obj, MOD_DATA_TRANSFER)

    if not bone_name:
        # No bone picked yet — clean slate so the user sees they need to choose.
        _remove_addon_modifier(obj, MOD_VERTEX_WEIGHT)
        return

    _ensure_vertex_group(obj, bone_name, weight=1.0)

    mod = obj.modifiers.get(MOD_VERTEX_WEIGHT)
    if mod is None:
        mod = obj.modifiers.new(name=MOD_VERTEX_WEIGHT, type='VERTEX_WEIGHT_EDIT')

    mod.vertex_group = bone_name
    mod.default_weight = 1.0
    mod.use_add = True
    mod.add_threshold = 0.0
    mod.use_remove = False


def _apply_skin_setup(obj, scene_props):
    """Dispatch on mode and update/clean modifiers accordingly."""
    if obj is None or obj.type != 'MESH':
        return
    mode = obj.skin_transfer.mode
    if mode == 'AS_IS':
        _remove_addon_modifier(obj, MOD_DATA_TRANSFER)
        _remove_addon_modifier(obj, MOD_VERTEX_WEIGHT)
    elif mode == 'TRANSFER':
        _apply_transfer(obj, scene_props.base_model)
    elif mode == 'BIND_TO_BONE':
        _apply_bind_to_bone(obj, obj.skin_transfer.bone)


def _retarget_all_transfer_objects(scene_props):
    """Walk every mesh tagged TRANSFER and point its Data Transfer modifier
    at the current base_model. Called when base_model changes."""
    base = scene_props.base_model
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        st = getattr(obj, 'skin_transfer', None)
        if st is None or st.mode != 'TRANSFER':
            continue
        mod = obj.modifiers.get(MOD_DATA_TRANSFER)
        if mod is not None:
            mod.object = base


# ---------------------------------------------------------------------------
# Property update callbacks
# ---------------------------------------------------------------------------

def _on_object_mode_update(self, context):
    obj = self.id_data
    if isinstance(obj, bpy.types.Object):
        _apply_skin_setup(obj, context.scene.skin_transfer_props)


def _on_object_bone_update(self, context):
    # Only re-apply if currently in bind-to-bone mode; otherwise the bone
    # field is just dormant state we don't want to act on.
    obj = self.id_data
    if isinstance(obj, bpy.types.Object) and self.mode == 'BIND_TO_BONE':
        _apply_skin_setup(obj, context.scene.skin_transfer_props)


def _on_base_model_update(self, context):
    _retarget_all_transfer_objects(self)


# ---------------------------------------------------------------------------
# Property groups
# ---------------------------------------------------------------------------

class SkinTransferObjectProps(PropertyGroup):
    mode: EnumProperty(
        name="Mode",
        description="How weights are assigned to this mesh",
        items=[
            ('AS_IS', "As-is",
             "Use this mesh's existing vertex groups; no modifier added"),
            ('TRANSFER', "Transfer",
             "Data Transfer of all vertex groups from the weighted base model"),
            ('BIND_TO_BONE', "Bind to Bone",
             "Vertex Weight Edit pinning every vertex to a single bone at weight 1.0"),
        ],
        default='AS_IS',
        update=_on_object_mode_update,
    )
    bone: StringProperty(
        name="Bone",
        description="Bone to bind this mesh to (used when Mode = Bind to Bone)",
        default="",
        update=_on_object_bone_update,
    )


class SkinTransferSceneProps(PropertyGroup):
    rig: PointerProperty(
        name="Rig",
        description="Armature the meshes will deform with — bone picker pulls from here",
        type=bpy.types.Object,
        poll=_poll_armature,
    )
    base_model: PointerProperty(
        name="Weighted Base Model",
        description="Mesh holding vertex groups for every bone — used as the Data Transfer source. Changing this re-targets every Transfer object",
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_on_base_model_update,
    )
    active_collection: PointerProperty(
        name="Collection",
        description="Collection to batch-configure parts in",
        type=bpy.types.Collection,
    )


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class SKINTRANSFER_OT_refresh_targets(Operator):
    bl_idname = "skintransfer.refresh_targets"
    bl_label = "Refresh All Transfer Targets"
    bl_description = ("Walk every Transfer / Bind-to-Bone tagged object and "
                      "rebuild its addon modifier from current settings")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.skin_transfer_props
        count = 0
        for obj in bpy.data.objects:
            if obj.type != 'MESH':
                continue
            if not hasattr(obj, 'skin_transfer'):
                continue
            _apply_skin_setup(obj, props)
            count += 1
        self.report({'INFO'}, f"Refreshed Skin Transfer setup on {count} mesh(es)")
        return {'FINISHED'}


class SKINTRANSFER_OT_apply_active(Operator):
    bl_idname = "skintransfer.apply_active"
    bl_label = "Re-apply to Active"
    bl_description = "Rebuild the Skin Transfer modifier on the active object from its current mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        _apply_skin_setup(context.active_object, context.scene.skin_transfer_props)
        return {'FINISHED'}


class SKINTRANSFER_OT_clear_active(Operator):
    bl_idname = "skintransfer.clear_active"
    bl_label = "Clear (Active)"
    bl_description = "Reset active object to As-is and remove its Skin Transfer modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        # Setting mode triggers the update callback which removes modifiers.
        context.active_object.skin_transfer.mode = 'AS_IS'
        return {'FINISHED'}


class SKINTRANSFER_OT_set_mode_batch(Operator):
    bl_idname = "skintransfer.set_mode_batch"
    bl_label = "Set Mode for All in Collection"
    bl_description = "Set every mesh in the active collection to the chosen mode"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        name="Mode",
        items=[
            ('AS_IS', "As-is", ""),
            ('TRANSFER', "Transfer", ""),
            ('BIND_TO_BONE', "Bind to Bone", ""),
        ],
    )

    def execute(self, context):
        props = context.scene.skin_transfer_props
        coll = props.active_collection
        if coll is None:
            self.report({'ERROR'}, "Pick a collection first")
            return {'CANCELLED'}
        count = 0
        for obj in coll.all_objects:
            if obj.type != 'MESH':
                continue
            obj.skin_transfer.mode = self.mode
            count += 1
        self.report({'INFO'}, f"Set {count} object(s) to {self.mode}")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------

class SKINTRANSFER_PT_main(Panel):
    bl_label = "Skin Transfer"
    bl_idname = "SKINTRANSFER_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Skin Transfer"

    def draw(self, context):
        layout = self.layout
        props = context.scene.skin_transfer_props

        col = layout.column(align=True)
        col.prop(props, "rig")
        col.prop(props, "base_model")

        layout.separator()
        layout.operator("skintransfer.refresh_targets", icon='FILE_REFRESH')


class SKINTRANSFER_PT_active_object(Panel):
    bl_label = "Active Object"
    bl_idname = "SKINTRANSFER_PT_active_object"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Skin Transfer"
    bl_parent_id = "SKINTRANSFER_PT_main"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        scene_props = context.scene.skin_transfer_props

        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a mesh object", icon='INFO')
            return

        layout.label(text=obj.name, icon='MESH_DATA')
        layout.prop(obj.skin_transfer, "mode", text="Mode")

        if obj.skin_transfer.mode == 'BIND_TO_BONE':
            row = layout.row()
            if scene_props.rig and scene_props.rig.type == 'ARMATURE':
                row.prop_search(obj.skin_transfer, "bone",
                                scene_props.rig.data, "bones", text="Bone")
            else:
                row.enabled = False
                row.label(text="Pick a rig first", icon='ERROR')

        layout.separator()
        row = layout.row(align=True)
        row.operator("skintransfer.apply_active", icon='FILE_REFRESH')
        row.operator("skintransfer.clear_active", icon='X')

        # Status: what addon-owned modifiers are present right now
        header, body = layout.panel("skintransfer_active_status", default_closed=True)
        header.label(text="Modifier Status", icon='MODIFIER')
        if body is not None:
            dx = obj.modifiers.get(MOD_DATA_TRANSFER)
            vw = obj.modifiers.get(MOD_VERTEX_WEIGHT)
            if dx is None and vw is None:
                body.label(text="No Skin Transfer modifiers", icon='RADIOBUT_OFF')
            if dx is not None:
                target = dx.object.name if dx.object else "<missing>"
                body.label(text=f"Data Transfer → {target}",
                           icon='MOD_DATA_TRANSFER')
            if vw is not None:
                body.label(text=f"Vertex Weight Edit → {vw.vertex_group or '<none>'}",
                           icon='MOD_VERTEX_WEIGHT')


class SKINTRANSFER_PT_batch(Panel):
    bl_label = "Batch by Collection"
    bl_idname = "SKINTRANSFER_PT_batch"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Skin Transfer"
    bl_parent_id = "SKINTRANSFER_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.skin_transfer_props

        layout.prop(props, "active_collection", text="Collection")
        coll = props.active_collection
        if coll is None:
            layout.label(text="Pick a collection to list parts", icon='INFO')
            return

        header, body = layout.panel("skintransfer_batch_setall", default_closed=True)
        header.label(text="Set all to…", icon='COLLAPSEMENU')
        if body is not None:
            row = body.row(align=True)
            op = row.operator("skintransfer.set_mode_batch", text="As-is")
            op.mode = 'AS_IS'
            op = row.operator("skintransfer.set_mode_batch", text="Transfer")
            op.mode = 'TRANSFER'
            op = row.operator("skintransfer.set_mode_batch", text="Bind")
            op.mode = 'BIND_TO_BONE'

        layout.separator()
        layout.label(text="Parts:")

        mesh_count = 0
        for obj in coll.all_objects:
            if obj.type != 'MESH':
                continue
            mesh_count += 1
            row = layout.row(align=True)
            row.label(text=obj.name, icon='MESH_DATA')
            row.prop(obj.skin_transfer, "mode", text="")
            if obj.skin_transfer.mode == 'BIND_TO_BONE':
                if props.rig and props.rig.type == 'ARMATURE':
                    row.prop_search(obj.skin_transfer, "bone",
                                    props.rig.data, "bones", text="")
                else:
                    row.label(text="", icon='ERROR')

        if mesh_count == 0:
            layout.label(text="(no meshes in this collection)", icon='INFO')


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = [
    SkinTransferObjectProps,
    SkinTransferSceneProps,
    SKINTRANSFER_OT_refresh_targets,
    SKINTRANSFER_OT_apply_active,
    SKINTRANSFER_OT_clear_active,
    SKINTRANSFER_OT_set_mode_batch,
    SKINTRANSFER_PT_main,
    SKINTRANSFER_PT_active_object,
    SKINTRANSFER_PT_batch,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.skin_transfer_props = PointerProperty(type=SkinTransferSceneProps)
    bpy.types.Object.skin_transfer = PointerProperty(type=SkinTransferObjectProps)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.skin_transfer_props
    del bpy.types.Object.skin_transfer


if __name__ == "__main__":
    register()
