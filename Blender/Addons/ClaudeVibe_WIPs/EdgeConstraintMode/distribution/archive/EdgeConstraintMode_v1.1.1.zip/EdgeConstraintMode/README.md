# Edge Constraint Mode

3ds Max-style **Edge Constraint** for Blender. When the mode is on, the
selection's Move / Rotate / Scale operations are projected onto each selected
vertex's incident edges — selected verts slide along the topology instead of
moving freely through space, while surrounding (unselected) geometry stays
in place.

## Status

v1.1.0 — Mesh edit mode. Covers G / R / S keys AND clicking the
viewport gizmos (Move / Rotate / Scale handles shown near the selection).
Blender's built-in tool gizmos are temporarily hidden while the mode is
active so the unconstrained ones can't be dragged by accident. Curve edit
mode and a richer gizmo layout (axis handles like Blender's defaults) are
on the roadmap; the solver is already transform-agnostic so adding new
drivers won't require core changes.

## Use

1. Enter **Mesh Edit mode** on a mesh.
2. Click the **edge-constraint toggle** in the 3D Viewport header (the
   `SNAP_EDGE` icon — it shows depressed while the mode is active).
3. Make a vert/edge/face selection. Three handles appear near the
   selection: Move (blue), Rotate (orange), Scale (green).
4. Either press **G / R / S** or click+drag the matching handle. Motion is
   projected onto each selected vertex's nearest incident edge.
5. Confirm with **LMB / Enter**, cancel with **RMB / Esc**.
6. Click the header button again (or leave edit mode) to turn the mode off.

## How it works

`EdgeConstraintSolver.apply_deltas(world_deltas)` is the only place that
touches topology. Every modal transform computes per-vertex world-space deltas
(translate = uniform drag, rotate = rotation about pivot, scale = radial from
pivot) and hands them to the solver, which picks the best-aligned incident
edge for each vert and walks along it. Future drivers (the multi-gizmo,
custom ops, curve mode) just need to produce world-space deltas — the solver
doesn't care where they came from.

## Settings

- **Stop at Selected** *(scene)* — when a slide walks past an edge end, stop
  if the next vertex is also selected. Prevents selected verts from colliding
  when several slide toward the same neighbour.

## Limitations (v1)

- Mesh only. Curve edit mode is on the roadmap.
- Pivot is selection median; 3D-cursor / active-element pivots are not wired
  up yet.
- Menu-invoked transforms (e.g. Mesh > Transform > Move) bypass the mode
  — only G/R/S keys and the in-viewport gizmo handles route through it.
