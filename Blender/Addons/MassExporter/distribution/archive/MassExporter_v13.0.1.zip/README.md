# Mass Collection Exporter v12.5.1

A powerful Blender addon for batch exporting collections with advanced parent-child relationship handling, automatic joining, and flexible export options.

## ✨ What's New in v12.5.1

### Export Selected Objects with Suffix Grouping
- **NEW**: "Export Selected Objects" now respects suffix grouping settings
- When suffix grouping is enabled, selected objects with matching base names are automatically grouped and joined
- Example: Select `cube`, `cube_COL`, and `cube_LOD0` → exports as single `cube.fbx` with all meshes joined
- Priority order: Suffix Grouping > Merge to Single > Individual exports

### What's New in v12.5.0

### Complete Property Integration
- **COMPLETE**: `Apply Modifiers` and `Move to Center` properties now fully integrated throughout ALL export paths
- Works correctly with: individual exports, merged exports, suffix grouping, subcollections, quick export buttons
- All export methods now consistently respect these per-collection settings

### Fixed Suffix Grouping
- **FIXED**: Suffix grouping now actually JOINS meshes into a single mesh object
- Previously: Exported multiple separate meshes into one file
- Now: Merges all grouped objects (e.g., cube + cube_COL) into a single joined mesh before export
- Result: Clean single-mesh exports perfect for game engines and external tools

---

## 📋 Quick Start

### Installation

1. Download the `MassExporter_v12.5.1.zip` file
2. Open Blender
3. Go to: **Edit → Preferences → Add-ons**
4. Click **Install...** and select the zip file
5. Enable the addon by checking the checkbox

### Basic Usage

1. **Open Panel**: Press `N` in 3D Viewport → Select **Mass Exporter** tab
2. **Add Collections**: Click `+` to add collections
3. **Set Export Path**: Click folder icon
4. **Enable Export**: Check the export checkbox
5. **Export**: Click **"Export All Collections"**

---

## 🎯 Key Features

### Core Functionality
- **Batch Collection Export**: Export multiple collections at once
- **Quick Export from Selection**: Export selected objects with one click
- **Suffix Grouping**: Group objects by base name (e.g., cube + cube_COL → cube.fbx)
- **Smart Empty Handling**: Automatic parent empty processing
- **Multiple Formats**: FBX, OBJ, DAE, glTF 2.0

### Export Modes
- Individual objects
- Merged collections
- Sub-collection based
- Suffix-grouped exports

---

## 🔧 Export Options

### Per-Collection Settings
- **Export Enabled**: Toggle export on/off
- **Merge to Single**: Combine all objects into one file
- **Sub-Collections as Single**: Export each sub-collection as merged object
- **Use Parent Empties**: Use empty objects as origins/centers
- **Center Each Empty**: Center empties at origin during export
- **Join Empty Children**: Combine all mesh children into single object
- **Apply Modifiers**: Apply modifiers before export *(NEW in v12.4)*
- **Move to Center**: Move objects to world origin during export *(NEW in v12.4)*
- **Group by Suffix**: Enable suffix-based grouping

### Transform Options
- Export at origin
- Apply transforms
- Axis orientation (Forward/Up)
- FBX-specific scaling

### Material Options
- Override materials
- Assign if no material
- Add M_ prefix

---

## 📖 Usage Examples

### Export Selected Objects Only (FIXED in v12.4)

**Before v12.4**: Exported entire collection
**After v12.4**: Exports ONLY selected objects

```
1. Select specific objects (Ctrl+Click)
2. Click "Export Selected Objects"
3. Result: Only those objects are exported
```

**With Subcollections**:
```
Collection: Buildings (export_subcollections_as_single: ON)
  ├─ Sub: House_A
  │   └─ Wall_01  ← Selected

Result: Entire House_A subcollection exported (respects parent settings)
```

### Export All with Status Feedback (NEW in v12.4)

```
1. Enable multiple collections for export
2. Click "Export All Collections"
3. Status bar shows: "Exported 3 collections: Props, Buildings, Vegetation"
```

### Using Suffix Grouping

**Basic Example:**
```
Objects:
  - sm_cube_4x4
  - sm_cube_4x4_COL
  - sm_cube_4x4_LOD0

Settings:
  ☑ Group by Suffix

Result: Single file "sm_cube_4x4.fbx" containing 3 separate meshes:
  - sm_cube_4x4
  - sm_cube_4x4_COL
  - sm_cube_4x4_LOD0
```

**Important:** Suffix grouping exports multiple meshes to **one file**, but keeps them as **separate mesh objects** (not joined). Perfect for game engine collision meshes, LODs, etc.

**Agnostic Grouping (Mixed Types):**
Suffix grouping works **agnostically** across objects, empties, and subcollections!

```
Collection Structure:
  Collection "Walls"
    ├─ Subcollection "foobar" (contains: wall mesh, floor mesh)
    └─ Object "foobar_COL" (collision mesh)

Settings:
  ☑ Group by Suffix
  Suffixes: _COL

Result: Single file "foobar.fbx" containing separate meshes:
  - wall (from subcollection)
  - floor (from subcollection)
  - foobar_COL (from parent collection)
```

The system strips suffixes from **all** types (objects, empties, subcollections) and groups by base name. Multiple meshes are exported to one file as separate objects, perfect for game engines that expect collision (_COL) and LOD meshes in the same file.

---

## 🐛 Known Issues & Limitations

### v12.5.1 Status

**Complete**:
- ✅ Export Selected Objects respects suffix grouping (v12.5.1)
- ✅ Export Selected Objects (fixed in v12.4)
- ✅ Status bar feedback with collection names (v12.4)
- ✅ Full integration of `apply_modifiers` property throughout ALL export paths (v12.5)
- ✅ Full integration of `move_to_center` property throughout ALL export paths (v12.5)
- ✅ Suffix grouping now joins meshes into single mesh (fixed in v12.5)
- ✅ All existing v12.3 features

All export methods now consistently respect per-collection properties. Suffix grouping works in both batch export and quick export modes.

---

## 📝 Version History

### v12.5.1 (Current) - 2026-01-13
- **NEW**: Export Selected Objects now respects suffix grouping settings
- **FIXED**: Added missing "Group by Suffix" checkbox to UI (was defined but not displayed)
- **FIXED**: Suffix grouping now exports multiple separate meshes to one file (not joined into single mesh)
- **NEW**: Suffix grouping checkbox now appears in both collection list and enhanced options panel
- **ENHANCED**: Detailed debug output shows grouping breakdown (objects, empties, subcollections)
- **DOCUMENTED**: Agnostic grouping - works across objects, empties, and subcollections with matching base names
- Selected objects with matching base names are exported to same file as separate mesh objects
- Priority: Suffix Grouping > Merge to Single > Individual
- Panel header now shows current version (v12.5.1)

### v12.5.0 - 2026-01-12
- **COMPLETE**: Full integration of `apply_modifiers` and `move_to_center` properties throughout ALL export paths
- All export methods (individual, merged, suffix grouping, subcollections, quick export) now consistently respect per-collection settings
- Refactored export method signatures to pass `item` parameter for property access
- Created `export_objects_joined()` helper method for mesh joining operations

### v12.4.1 - 2026-01-11
- **FIXED**: Export Selected Objects now exports ONLY selected objects
- **FIXED**: Respects collection's `merge_to_single` setting
- **NEW**: Status bar shows exported collection names
- **NEW**: Per-collection `Apply Modifiers` property (default OFF)
- **NEW**: Per-collection `Move to Center` property (default ON)
- Improved selection handling in quick export operators

### v12.3.0 - Suffix Grouping
- Added suffix grouping for collision/LOD exports
- Customizable suffix definitions
- Case-insensitive matching

### v12.2.0 - Export Selected Objects
- Added "Export Selected Object(s)" quick export

### v12.1.0 - Quick Export from Selection
- Export collection or sub-collections of selected object

### v12.0.0 - Fallback Export
- Export meshes even when no empties present
- Improved error handling

---

## 🤝 Support

**Author**: Stephan Viranyi (Stephko)
**Email**: stephko@viranyi.de
**Portfolio**: https://www.artstation.com/stephko

### Troubleshooting

1. **Enable Debug Mode** in panel
2. Check **Console** (Window → Toggle System Console)
3. Test with **Debug Tools** buttons
4. Verify **collection structure** in Outliner

---

## 📄 License

Created with Claude AI. Free to use in Blender projects.

---

**Happy Exporting! 🚀**
