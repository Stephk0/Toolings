"""bpy-free logic."""
