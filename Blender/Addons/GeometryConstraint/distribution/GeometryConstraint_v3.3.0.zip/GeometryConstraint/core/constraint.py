"""Edge / Face / Normal constraint solver (bpy-free).

Model (mirrors 3ds Max Editable Poly "Constraints"):

* The transform (move / rotate / scale, any pivot, any axis lock) first
  computes a *free* target position for every selected vertex.
* The constraint then snaps that target back onto the vertex's allowed
  geometry, measured on the ORIGINAL mesh:

  EDGE   - the closest point on the vertex's "rail" network: the edges that
           leave the vertex towards unselected geometry. By default a vertex
           stops at the far end of its edge (``stop_at_vertices``), so it
           never slides through an existing loop; with that off it continues
           edge by edge for ``reach`` steps.
  FACE   - the closest point on the surface of the polygons around the
           vertex (again grown ``reach`` rings), so it slides over the
           surface instead of leaving it.
  NORMAL - the target projected onto the vertex normal line.

Rails deliberately skip edges/faces that lie *inside* the selection: a
selected loop on a cube can only slide along the edges that cross it, which
is exactly what turns a rotation of that loop into a shear that keeps the
cube a cube.

Everything here works on plain 3-tuples; the Blender wrapper converts to and
from world space so object scale does not skew the projection.
"""

import math

from . import vec

MODE_NONE = 'NONE'
MODE_EDGE = 'EDGE'
MODE_FACE = 'FACE'
MODE_NORMAL = 'NORMAL'
MODES = (MODE_NONE, MODE_EDGE, MODE_FACE, MODE_NORMAL)

# Hotkey cycles: each press steps to the next state, NONE meaning off.
CYCLE_FULL = (MODE_NONE, MODE_EDGE, MODE_FACE, MODE_NORMAL)
CYCLE_SURFACE = (MODE_NONE, MODE_EDGE, MODE_FACE)   # along the surface: no Normal


def next_in_cycle(current, order):
    """The state after ``current`` in ``order`` (wrapping). A state the
    cycle doesn't contain (Normal in the surface cycle) steps to off."""
    if current not in order:
        return order[0]
    return order[(order.index(current) + 1) % len(order)]

DEFAULT_REACH = 4
# Walking past a vertex only continues onto an edge within ~60 deg of the
# previous one.
TURN_LIMIT_COS = 0.5
# Edges that leave the selection are the rails. Edges inside it (a loop's
# own edges, the rungs between two selected loops) are used only when the
# vertex has no leaving edge, or when the motion points back INTO the
# selection (every leaving edge opposes it by more than this fraction of the
# motion) - e.g. two loops scaled toward each other. Sideways motion along a
# loop is rejected: otherwise the "hinge" verts of a tilted cylinder/sphere
# loop slide along the loop and kink it.
MIN_RAIL_SCORE = 1e-6
INTO_SELECTION = 0.25


class MeshData:
    """Plain-data mesh snapshot: positions, edges, faces, selection."""

    def __init__(self, positions, edges, faces, selected, normals=None, selected_edges=None):
        self.positions = [tuple(p) for p in positions]
        self.edges = [tuple(e) for e in edges]
        self.faces = [tuple(f) for f in faces]
        self.selected = set(selected)
        self._normals = normals
        # The mesh's own edge selection, as (a, b) pairs. In Edge / Face select
        # mode an edge can join two selected verts without being selected
        # itself (the rung between two selected edges); it is then a rail.
        # None: an edge counts as selected when both its verts are.
        self.selected_edges = (None if selected_edges is None
                               else {_edge_key(a, b) for a, b in selected_edges})

        n = len(self.positions)
        self.vert_edges = [[] for _ in range(n)]
        for ei, (a, b) in enumerate(self.edges):
            self.vert_edges[a].append(ei)
            self.vert_edges[b].append(ei)

        self.vert_faces = [[] for _ in range(n)]
        self.edge_faces = {}
        for fi, f in enumerate(self.faces):
            for i, v in enumerate(f):
                self.vert_faces[v].append(fi)
                key = _edge_key(v, f[(i + 1) % len(f)])
                self.edge_faces.setdefault(key, []).append(fi)

    def other(self, ei, v):
        a, b = self.edges[ei]
        return b if a == v else a

    def edge_fully_selected(self, ei):
        a, b = self.edges[ei]
        if self.selected_edges is not None:
            return _edge_key(a, b) in self.selected_edges
        return a in self.selected and b in self.selected

    def face_fully_selected(self, fi):
        return all(v in self.selected for v in self.faces[fi])

    def vertex_normal(self, v):
        if self._normals is not None:
            return vec.normalized(self._normals[v])
        # Angle-weighted, like Blender's own vertex normals.
        pos = self.positions
        acc = (0.0, 0.0, 0.0)
        for fi in self.vert_faces[v]:
            f = self.faces[fi]
            i = f.index(v)
            a = vec.normalized(vec.sub(pos[f[i - 1]], pos[v]))
            b = vec.normalized(vec.sub(pos[f[(i + 1) % len(f)]], pos[v]))
            ang = math.acos(max(-1.0, min(1.0, vec.dot(a, b))))
            n = vec.normalized(_face_area_normal(pos, f))
            acc = vec.add(acc, vec.mul(n, ang))
        return vec.normalized(acc)


def _edge_key(a, b):
    return (a, b) if a < b else (b, a)


def _face_area_normal(positions, face):
    """Newell normal scaled by area (unnormalized)."""
    nx = ny = nz = 0.0
    count = len(face)
    for i in range(count):
        cx, cy, cz = positions[face[i]]
        nx_, ny_, nz_ = positions[face[(i + 1) % count]]
        nx += (cy - ny_) * (cz + nz_)
        ny += (cz - nz_) * (cx + nx_)
        nz += (cx - nx_) * (cy + ny_)
    return (nx * 0.5, ny * 0.5, nz * 0.5)


# ---------------------------------------------------------------------------
# Per-vertex constraint shapes
# ---------------------------------------------------------------------------

class _FreeConstraint:
    def project(self, target):
        return target


class EdgeRails:
    """Slide a vertex along its edges, 3ds Max style.

    The displacement picks the incident edge it is most aligned with (largest
    positive dot), the vertex moves by the projected length, and if that runs
    past the edge's far vertex the leftover keeps going along the next edge -
    but only one that roughly continues the path (within ``turn_limit``), so
    a loop slides along a bent column of edges but stops at a cube corner
    instead of wrapping onto the cap. With ``stop_at_vertices`` (the default)
    the walk ends at the first vertex it reaches, like Max.
    """

    def __init__(self, mesh, v, *, reach=DEFAULT_REACH, stop_at_selected=True,
                 stop_at_vertices=True, turn_limit_cos=TURN_LIMIT_COS):
        self.mesh = mesh
        self.v = v
        self.origin = mesh.positions[v]
        self.reach = 1 if stop_at_vertices else reach
        self.stop_at_selected = stop_at_selected
        self.turn_limit_cos = turn_limit_cos
        self.path = []          # edges the last project() slid along (overlay)

    def _edges_from(self, u, came_from):
        """Yield (other, unit_dir, length, prefers) for u's edges."""
        pos = self.mesh.positions
        for ei in self.mesh.vert_edges[u]:
            w = self.mesh.other(ei, u)
            if w == came_from:
                continue
            d = vec.sub(pos[w], pos[u])
            ln = vec.length(d)
            if ln < 1e-12:
                continue
            leaves = not self.mesh.edge_fully_selected(ei)
            yield w, vec.mul(d, 1.0 / ln), ln, leaves

    def _chain_end(self, u):
        """u ends a selected edge / chain: exactly one of its edges is selected."""
        return sum(1 for ei in self.mesh.vert_edges[u] if self.mesh.edge_fully_selected(ei)) == 1

    def _pick(self, u, came_from, prev_dir, remaining, moving=False):
        """The edge at u the motion slides along: (w, unit_dir, length, s) or None.

        moving: the whole selection is translated by one offset. The end of a
        selected edge / chain may then slide along that edge itself, like
        Vertex Slide, so an edge can be pushed along its own length. (Under
        rotate / scale that would collapse the edge instead.)
        """
        # Best positive alignment per tier: [leaving edges, in-selection edges].
        rlen = vec.length(remaining)
        tiers = [None, None]
        scores = [MIN_RAIL_SCORE * rlen] * 2
        any_leaving = False
        max_leaving = -float("inf")
        candidates = [c for c in self._edges_from(u, came_from)
                      if prev_dir is None or vec.dot(c[1], prev_dir) >= self.turn_limit_cos]
        leaving_dirs = [t for _w, t, _ln, leaves in candidates if leaves]
        along_self = moving and self._chain_end(u)
        for w, t, ln, leaves in candidates:
            s = vec.dot(remaining, t)
            if leaves:
                any_leaving = True
                max_leaving = max(max_leaving, s)
            elif along_self:
                pass
            elif leaving_dirs and not any(vec.dot(t, ld) < -self.turn_limit_cos
                                          for ld in leaving_dirs):
                # An in-selection edge is a rail only where it continues a
                # leaving one through the vertex (the rung between two
                # selected loops), never sideways along the loop itself.
                continue
            k = 0 if leaves or along_self else 1
            if s > scores[k]:
                scores[k], tiers[k] = s, (w, t, ln, s)
        best = tiers[0]
        if best is None and (not any_leaving or max_leaving < -INTO_SELECTION * rlen):
            best = tiers[1]
        return best

    def rail(self, delta):
        """The first edge a move by ``delta`` slides along, or None."""
        if vec.length_sq(delta) < 1e-24:
            return None
        return self._pick(self.v, None, None, delta, moving=True)

    def side_rail(self, side):
        """The leaving edge closest to ``side`` (not pointing away from it)."""
        best, best_d = None, -self.turn_limit_cos
        for w, t, ln, leaves in self._edges_from(self.v, None):
            d = vec.dot(t, side)
            if leaves and d > best_d:
                best, best_d = (w, t, ln, d), d
        return best

    def candidate_edges(self):
        """Every edge this vertex could slide along (for the overlay)."""
        end = self._chain_end(self.v)
        return [(self.origin, self.mesh.positions[w])
                for w, _t, _ln, leaves in self._edges_from(self.v, None) if leaves or end]

    def project(self, target, moving=False):
        mesh = self.mesh
        remaining = vec.sub(target, self.origin)
        self.path = []
        if vec.length_sq(remaining) < 1e-24:
            return self.origin
        pos = self.origin
        u, came_from, prev_dir = self.v, None, None
        for _step in range(max(1, self.reach)):
            best = self._pick(u, came_from, prev_dir, remaining, moving)
            if best is None:
                break
            w, t, ln, s = best
            self.path.append((mesh.positions[u], mesh.positions[w]))
            if s <= ln:
                return vec.add(pos, vec.mul(t, s))
            # Ran past the far vertex: land on it, consume, keep walking.
            pos = mesh.positions[w]
            remaining = vec.sub(remaining, vec.mul(t, ln))
            if self.stop_at_selected and w in mesh.selected:
                break
            came_from, u, prev_dir = u, w, t
        return pos


class FacePatch:
    """A set of triangles; project() returns the closest point on the patch."""

    def __init__(self, origin, triangles):
        self.origin = origin
        self.triangles = triangles

    def project(self, target):
        if not self.triangles:
            return self.origin
        best = self.origin
        best_d = vec.dist_sq(target, best)
        for a, b, c in self.triangles:
            q = vec.closest_point_on_triangle(target, a, b, c)
            d = vec.dist_sq(target, q)
            if d < best_d - 1e-15:
                best, best_d = q, d
        return best


class NormalLine:
    def __init__(self, origin, normal):
        self.origin = origin
        self.normal = normal

    def project(self, target):
        if vec.length_sq(self.normal) < 1e-20:
            return self.origin
        t = vec.dot(vec.sub(target, self.origin), self.normal)
        return vec.add(self.origin, vec.mul(self.normal, t))


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------

def edge_rails_for(mesh, v, *, reach=DEFAULT_REACH, stop_at_selected=True,
                   stop_at_vertices=True):
    return EdgeRails(mesh, v, reach=reach, stop_at_selected=stop_at_selected,
                     stop_at_vertices=stop_at_vertices)


def _triangulate(positions, face):
    p0 = positions[face[0]]
    return [(p0, positions[face[i]], positions[face[i + 1]])
            for i in range(1, len(face) - 1)]


def face_patch_for(mesh, v, *, reach=DEFAULT_REACH, stop_at_selected=True):
    """Collect the surface triangles vertex v may slide over.

    Every face counts, selected or not: positions are the pre-transform
    ones, so this is simply "the original surface within ``reach`` face
    rings". (Excluding the selection's own faces stranded the trailing verts
    of a moved patch behind it.) stop_at_selected only applies to Edge.
    """
    start = list(mesh.vert_faces[v])
    seen = set(start)
    frontier = list(start)
    depth = 1
    while frontier and depth < reach:
        nxt = []
        for fi in frontier:
            f = mesh.faces[fi]
            for i, a in enumerate(f):
                b = f[(i + 1) % len(f)]
                for nf in mesh.edge_faces.get(_edge_key(a, b), ()):
                    if nf not in seen:
                        seen.add(nf)
                        nxt.append(nf)
        frontier = nxt
        depth += 1

    tris = []
    for fi in seen:
        tris.extend(_triangulate(mesh.positions, mesh.faces[fi]))
    return FacePatch(mesh.positions[v], tris)


def build_constraints(mesh, mode, *, reach=DEFAULT_REACH, stop_at_selected=True,
                      stop_at_vertices=True):
    """Return {vert_index: constraint} for every selected vertex."""
    out = {}
    for v in mesh.selected:
        if mode == MODE_EDGE:
            out[v] = edge_rails_for(mesh, v, reach=reach,
                                    stop_at_selected=stop_at_selected,
                                    stop_at_vertices=stop_at_vertices)
        elif mode == MODE_FACE:
            out[v] = face_patch_for(mesh, v, reach=reach,
                                    stop_at_selected=stop_at_selected)
        elif mode == MODE_NORMAL:
            out[v] = NormalLine(mesh.positions[v], mesh.vertex_normal(v))
        else:
            out[v] = _FreeConstraint()
    return out


def solve(constraints, targets, *, even=False):
    """Project free targets {v: point} through constraints -> {v: point}.

    even: when the transform is a pure move (every target has the same
    offset), each connected piece of an Edge selection slides one shared
    distance, each vertex along its own edge, like Blender's Edge Slide in
    Even mode. The selection keeps its size instead of every vertex taking
    its own share of the drag.
    """
    delta = _common_delta(constraints, targets)
    if even and delta is not None:
        return _solve_even(constraints, targets, delta)
    moving = delta is not None
    return {v: (constraints[v].project(t, moving) if moving else constraints[v].project(t))
            if v in constraints else t
            for v, t in targets.items()}


def _common_delta(constraints, targets):
    delta = None
    for v, t in targets.items():
        c = constraints.get(v)
        if not isinstance(c, EdgeRails):
            return None
        d = vec.sub(t, c.origin)
        if delta is None:
            delta = d
            tol = 1e-5 * (1.0 + vec.length(d))
        elif (abs(d[0] - delta[0]) > tol or abs(d[1] - delta[1]) > tol
              or abs(d[2] - delta[2]) > tol):
            return None
    if delta is None or vec.length_sq(delta) < 1e-24:
        return None
    return delta


def _islands(rails):
    """Groups of selected verts joined by selected edges."""
    seen, out = set(), []
    for start in rails:
        if start in seen:
            continue
        mesh = rails[start].mesh
        seen.add(start)
        stack, island = [start], []
        while stack:
            u = stack.pop()
            island.append(u)
            for ei in mesh.vert_edges[u]:
                w = mesh.other(ei, u)
                if w in rails and w not in seen and mesh.edge_fully_selected(ei):
                    seen.add(w)
                    stack.append(w)
        out.append(island)
    return out


def _solve_even(rails, targets, delta):
    out = {}
    for island in _islands({v: rails[v] for v in targets}):
        picks = {v: rails[v].rail(delta) for v in island}
        got = [p for p in picks.values() if p is not None]
        if not got:
            for v in island:
                rails[v].path = []
                out[v] = rails[v].origin
            continue
        # Least squares: the shared distance that best follows the drag.
        dist = sum(p[3] for p in got) / len(got)
        # A vertex with no edge along the drag still slides with the rest,
        # along its edge on the same side (like Edge Slide), instead of
        # staying behind and stretching the selection.
        side = vec.normalized(_sum(p[1] for p in got))
        for v in island:
            if picks[v] is None and vec.length_sq(side) > 0.0:
                picks[v] = rails[v].side_rail(side)
        got = [p for p in picks.values() if p is not None]
        stop = rails[island[0]].reach == 1
        if stop:
            dist = min(dist, min(p[2] for p in got))   # the whole piece stops together
        for v in island:
            r, p = rails[v], picks[v]
            if p is None:
                r.path = []
                out[v] = r.origin
            elif stop:
                w, t, _ln, _s = p
                r.path = [(r.origin, r.mesh.positions[w])]
                out[v] = vec.add(r.origin, vec.mul(t, dist))
            else:
                out[v] = r.project(vec.add(r.origin, vec.mul(p[1], dist)), moving=True)
    return out


def _sum(vectors):
    acc = (0.0, 0.0, 0.0)
    for d in vectors:
        acc = vec.add(acc, d)
    return acc
